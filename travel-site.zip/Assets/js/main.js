$(document).ready(function() {
            $(document).on("click", ".navbar-toggle", function() {
                $(".navbar").find(".navbar-collapse").slideToggle();
            });


            //Search Box on Click

            function buttonUp() {
                var inputVal = $('.searchbox-input').val();
                inputVal = $.trim(inputVal).length;
                if (inputVal !== 0) {
                    $('.searchbox-icon').css('display', 'none');
                } else {
                    $('.searchbox-input').val('');
                    $('.searchbox-icon').css('display', 'block');
                }
            }


            //To scroll to top
            $(window).scroll(function() {
                if ($(this).scrollTop() > 200) {
                    $('.scrollToTop').fadeIn();
                } else {
                    $('.scrollToTop').fadeOut();
                }
            });

            //Click event to scroll to top
            $('.scrollToTop').click(function() {
                $('html, body').animate({ scrollTop: 0 }, 600);
                return false;
            });


            //Chevron-down slide animation
            $(".banner-chevron a").click(function(e) {
                e.preventDefault();

                var target = $(this).attr("href");
                $('html, body').animate({
                    scrollTop: $(target).offset().top,
                }, 400);

            });

            //for tab collapse...

            $('.package-tab').tabCollapse();

            //for tab collapse seasonal section

            $('.seasonal #myTabs a').click(function(e) {
                e.preventDefault()
                $(this).tab('show')
            });

            $(document).on("click", ".feature-menu .panel-title a", function() {
                $("html,body").animate({
                    scrollTop: $(this).parents('.panel-group').offset().top
                }, 500);
            });

            $('.owl-carousel').owlCarousel({
                loop: true,
                margin: 10,
                responsiveClass: true,
                responsive: {
                    0: {
                        items: 1,
                        autoplay: true,
                        autoplaySpeed: 1000,
                        nav: false
                    },
                    600: {
                        items: 2,
                        autoplay: true,
                        nav: false
                    },
                    1000: {
                        items: 3,
                        autoplay: true,
                        nav: true,
                        loop: true
                    }
                }
            });
});